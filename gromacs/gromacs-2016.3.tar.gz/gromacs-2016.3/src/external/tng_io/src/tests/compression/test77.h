#define TESTNAME "Coding. Compress zeros test. velocities stopbits inter"
#define FILENAME "test77.tng_compress"
#define ALGOTEST
#define NATOMS 100
#define CHUNKY 100
#define SCALE 0.
#define PRECISION 0.01
#define WRITEVEL 1
#define VELPRECISION 0.1
#define INITIALCODING 3
#define INITIALCODINGPARAMETER -1
#define CODING 3
#define CODINGPARAMETER -1
#define INITIALVELCODING 1
#define INITIALVELCODINGPARAMETER -1
#define VELCODING 6
#define VELCODINGPARAMETER -1
#define INTMIN1 0
#define INTMIN2 0
#define INTMIN3 0
#define INTMAX1 0
#define INTMAX2 0
#define INTMAX3 0
#define NFRAMES 100
#define EXPECTED_FILESIZE 13863.
